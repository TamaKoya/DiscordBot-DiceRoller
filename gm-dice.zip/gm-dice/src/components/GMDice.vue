<script setup>
import { DiceRoller } from '@dice-roller/vue'
</script>

<template>
    <div class="greetings">
        <h1 class="green">{{ msg }}</h1>
            <h3>
                GM's Dices
            </h3>
            <p>Input your desired rolls using roll notation into the text box and press 'Roll' button.</p>
            <p>The results will appear just above the textbox.</p>
            <br>
            <br>
    </div>
    <DiceRoller />
</template>

<style>

.dice-roller-output {
    color: #42B883;
    font-size: 32px;
}

</style>