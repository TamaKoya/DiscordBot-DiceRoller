<script setup>
import { RouterLink, RouterView } from 'vue-router'
import GMDice from './components/GMDice.vue'
</script>

<template>
  <header>
    <div class="wrapper">
      <GMDice />
    </div>
  </header>
</template>

<style scoped>

@media (min-width: 1024px) {
  header {
    display: flex;
    place-items: center;
    padding-right: calc(var(--section-gap) / 2);
  }
}
</style>